package com.yourname.morsecore;

import android.os.Bundle;
import android.widget.*;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputText;
    private TextView outputMorse;
    private FileManager fileManager;
    private AudioTonePlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText = findViewById(R.id.inputText);
        outputMorse = findViewById(R.id.outputMorse);
        fileManager = new FileManager(this);
        player = new AudioTonePlayer();

        Button buttonSend = findViewById(R.id.buttonSend);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = inputText.getText().toString().trim();
                if (!text.isEmpty()) {
                    String morse = MorseEncoder.encode(text);
                    outputMorse.setText("Морзе:\n" + morse);
                    player.playMorse(morse);
                    fileManager.saveTransmission("sent", text, morse);
                }
            }
        });

        Button buttonListen = findViewById(R.id.buttonListen);
        buttonListen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                outputMorse.setText("Приём пока в разработке");
            }
        });
    }
}