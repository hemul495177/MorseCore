package com.yourname.morsecore;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileManager {
    private final Context context;

    public FileManager(Context context) {
        this.context = context;
    }

    public void saveTransmission(String type, String text, String morse) {
        try {
            File dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            if (dir != null) {
                File file = new File(dir, type + "_log.txt");
                FileWriter writer = new FileWriter(file, true);
                writer.write("Text: " + text + "\nMorse: " + morse + "\n\n");
                writer.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}